import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notes-header',
  templateUrl: './notes-header.component.html',
  styleUrls: ['./notes-header.component.scss']
})
export class NotesHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
