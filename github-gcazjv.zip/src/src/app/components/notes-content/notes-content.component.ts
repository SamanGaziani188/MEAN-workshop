import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notes-content',
  templateUrl: './notes-content.component.html',
  styleUrls: ['./notes-content.component.scss']
})
export class NotesContentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
